-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: wine-bank
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `carrello`
--

DROP TABLE IF EXISTS `carrello`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `carrello` (
  `codice` varchar(50) NOT NULL,
  `nome_vino` varchar(50) NOT NULL,
  `prezzo` varchar(50) NOT NULL,
  `pezzi` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `vendita` varchar(50) NOT NULL,
  `img1` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carrello`
--

LOCK TABLES `carrello` WRITE;
/*!40000 ALTER TABLE `carrello` DISABLE KEYS */;
/*!40000 ALTER TABLE `carrello` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fattura`
--

DROP TABLE IF EXISTS `fattura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fattura` (
  `idfattura` int(11) NOT NULL AUTO_INCREMENT,
  `codice_vino` varchar(50) NOT NULL,
  `nome_vino` varchar(50) NOT NULL,
  `pezzi` varchar(50) NOT NULL,
  `user` varchar(50) NOT NULL,
  `prezzo` varchar(50) NOT NULL,
  `credit` varchar(45) NOT NULL,
  `vendita` varchar(50) NOT NULL,
  `stato` varchar(45) NOT NULL DEFAULT 'In attesa',
  PRIMARY KEY (`idfattura`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fattura`
--

LOCK TABLES `fattura` WRITE;
/*!40000 ALTER TABLE `fattura` DISABLE KEYS */;
INSERT INTO `fattura` VALUES (2,'1223','Taurasi DOCG','1','ramsey','31.0','43543543534','15-02-2018','in attesa'),(4,'2134','Charmes Chambertin Grand Cru Rouge','1','ramsey','218.9','123456789','17-02-2018','errore'),(5,'3564','Falerno del Massico','1','ramsey','26.9','435345345','17-02-2018','spedito'),(6,'3456','Argiolas Turriga Isola dei Nuraghi IGT','4','ramsey','332.0','435345345','17-02-2018','completato'),(7,'3456','Argiolas Turriga Isola dei Nuraghi IGT','2','croix1','166.0','52345234','11-02-2018','spedito'),(8,'1223','Taurasi DOCG','5','croix1','155.0','52345234','11-02-2018','completato'),(10,'4345','Monprivato Barolo DOCG','1','ramsey','73.9','465436436','17-02-2018','in attesa'),(12,'4567','Piedirosso Campi Flegrei','1','ramsey','6.9','435643534','17-02-2018','spedito'),(14,'2134','Charmes Chambertin Grand Cru Rouge','1','ramsey','218.9','4543543','17-02-2018','errore'),(15,'6547','Coates & Seely','1','ramsey','48.35','4214214','17-02-2018','spedito'),(16,'4345','Monprivato Barolo DOCG','1','ramsey','73.9','534543534','17-02-2018','in attesa'),(20,'2345','Soave Classico DOC La Rocca','1','croix1','25.0','5645645','17-02-2018','spedito');
/*!40000 ALTER TABLE `fattura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prodotto`
--

DROP TABLE IF EXISTS `prodotto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prodotto` (
  `codice` varchar(45) NOT NULL,
  `nome_vino` varchar(45) NOT NULL,
  `categoria` varchar(10) NOT NULL,
  `prezzo` double NOT NULL DEFAULT '0',
  `pezzi` int(11) DEFAULT '0',
  `annata` varchar(50) DEFAULT '1900',
  `img1` varchar(45) DEFAULT 'products/default_img.png',
  PRIMARY KEY (`codice`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prodotto`
--

LOCK TABLES `prodotto` WRITE;
/*!40000 ALTER TABLE `prodotto` DISABLE KEYS */;
INSERT INTO `prodotto` VALUES ('0000','Nuovo Vino','Nuovo',44,44,'0000','products/default_img.png'),('1223','Taurasi DOCG','Rosso',31,80,'1995','products/taurasidocg.jpg'),('2134','Charmes Chambertin Grand Cru Rouge','Rosso',218.9,3,'2011','products/CharmesChambertinGrandCru.jpg'),('2345','Soave Classico DOC La Rocca','Bianco',25,41,'2012','products/soaveclassicolarocca.jpg'),('3456','Argiolas Turriga Isola dei Nuraghi IGT','Rosso',83,20,'2004','products/turrigaisoladeinaufraghi.jpg'),('3564','Falerno del Massico','Bianco',26.9,22,'2008','products/falernodelmessico.jpg'),('4345','Monprivato Barolo DOCG','Rosso',73.9,78,'2012','products/monprivatobarolodocg.jpg'),('4567','Piedirosso Campi Flegrei','Rosso',6.9,71,'2015','products/piedirossocampiflegrei.jpg'),('6023','Aglianico del Taburno','Rosso',12.5,66,'2012','products/aglianicodeltaburno.jpg'),('6547','Coates & Seely','Rosè',48.35,86,'2015','products/coatesandseely.jpg'),('7754','Tebbiano d\'Abruzzo DOC','Bianco',19,40,'2013','products/trebbianodabruzzo.png'),('8547','Aglianico Donnaluna','Rosso',10.16,78,'2012','products/aglianicodonnaluna.jpg');
/*!40000 ALTER TABLE `prodotto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `ID` varchar(20) NOT NULL,
  `password` varchar(45) NOT NULL,
  `CF` char(16) NOT NULL,
  `nome` varchar(45) NOT NULL,
  `cognome` varchar(45) NOT NULL,
  `tipologia` varchar(45) NOT NULL DEFAULT 'default',
  `email` varchar(70) DEFAULT 'null',
  `indirizzo` varchar(45) DEFAULT 'null',
  `recapito` varchar(45) DEFAULT 'null',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('bot','bot','btbtbtbtbtbtbtbt','Bot','Bot','default','null','null','null'),('croix1','croix1','crcrcrcrcrcrcrcr','Carlo','Cracco','default','fwef','fewfwe34','2452345'),('ramsey','ramsey','rmrmrmrmrmrmrmrr','Gordon','Ramsey','default','wefwe@wef.com','Wall Street (NY)','+39 342 234 11 22'),('redhood','redhood','xxxxxxxxxxxxxxxx','Jason','Todd','admin','null','null','null'),('user1','user1','fbfbfbfbfbfbfbfb','Foo','Bar','default','gvrdg@ergf.com','Via Cammin di Dante 1','123456789'),('wayne','wayne','wawawawawawawawa','Bruce','Wayne','responsabile','null','null','null');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-02-19  3:08:36
